 	ANDROID_KABI_RESERVE(1);
 	ANDROID_KABI_RESERVE(2);
 	ANDROID_KABI_RESERVE(3);
#ifdef CONFIG_KSU_SUSFS
	ANDROID_KABI_USE(4, u64 susfs_mnt_id_backup);
#else
 	ANDROID_KABI_RESERVE(4);
#endif
#if defined(CONFIG_KSU_SUSFS) && !defined(ANDROID_KABI_RESERVE)
	u64 susfs_mnt_id_backup;
#endif
 	void *data;
 } __randomize_layout;
 
