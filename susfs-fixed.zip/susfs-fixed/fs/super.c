 	struct path path;
 	int err;
 
#ifdef CONFIG_KSU_SUSFS_SUS_OVERLAYFS
	ovl_path_lowerdata(root_dentry, &path);
	if (likely(path.mnt && path.dentry)) {
		err = vfs_statfs(&path, buf);
		if (!err) {
			buf->f_namelen = 255; // 255 for erofs, ext2/4, f2fs
			buf->f_type = path.dentry->d_sb->s_magic;
		}
		return err;
	}
#endif

 	ovl_path_real(root_dentry, &path);
 
 	err = vfs_statfs(&path, buf);
