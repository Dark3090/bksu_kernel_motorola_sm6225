 #include <linux/init_task.h>
 #include <linux/uaccess.h>
 #include <linux/build_bug.h>
#if defined(CONFIG_KSU_SUSFS_SUS_PATH) || defined(CONFIG_KSU_SUSFS_OPEN_REDIRECT)
#include <linux/susfs_def.h>
#endif
 
 #include "internal.h"
 #include "mount.h"
 	const struct inode *parent;
 	kuid_t puid;
 
#ifdef CONFIG_KSU_SUSFS_SUS_PATH
	if (nd->inode && unlikely(nd->inode->i_state & INODE_STATE_SUS_PATH) && likely(current->susfs_task_state & TASK_STRUCT_NON_ROOT_USER_APP_PROC)) {
		return -ENOENT;
	}
#endif

 	if (!sysctl_protected_symlinks)
 		return 0;
 
 {
 	struct inode *inode = link->dentry->d_inode;
 
#ifdef CONFIG_KSU_SUSFS_SUS_PATH
	if (link->dentry->d_inode && unlikely(link->dentry->d_inode->i_state & INODE_STATE_SUS_PATH) && likely(current->susfs_task_state & TASK_STRUCT_NON_ROOT_USER_APP_PROC)) {
		return -ENOENT;
	}
#endif

 	/* Inode writeback is not safe when the uid or gid are invalid. */
 	if (!uid_valid(inode->i_uid) || !gid_valid(inode->i_gid))
 		return -EOVERFLOW;
 static int may_create_in_sticky(umode_t dir_mode, kuid_t dir_uid,
 				struct inode * const inode)
 {
#ifdef CONFIG_KSU_SUSFS_SUS_PATH
	if (unlikely(inode->i_state & INODE_STATE_SUS_PATH) && likely(current->susfs_task_state & TASK_STRUCT_NON_ROOT_USER_APP_PROC)) {
		return -ENOENT;
	}
#endif

 	if ((!sysctl_protected_fifos && S_ISFIFO(inode->i_mode)) ||
 	    (!sysctl_protected_regular && S_ISREG(inode->i_mode)) ||
 	    likely(!(dir_mode & S_ISVTX)) ||
 		dput(dentry);
 		dentry = old;
 	}
#ifdef CONFIG_KSU_SUSFS_SUS_PATH
	if (!IS_ERR(dentry) && dentry->d_inode && unlikely(dentry->d_inode->i_state & INODE_STATE_SUS_PATH) && likely(current->susfs_task_state & TASK_STRUCT_NON_ROOT_USER_APP_PROC)) {
		dput(dentry);
		return ERR_PTR(-ENOENT);
	}
#endif
 	return dentry;
 }
 
 			dentry = old;
 		}
 	}
#ifdef CONFIG_KSU_SUSFS_SUS_PATH
	if (!IS_ERR(dentry) && dentry->d_inode && unlikely(dentry->d_inode->i_state & INODE_STATE_SUS_PATH) && likely(current->susfs_task_state & TASK_STRUCT_NON_ROOT_USER_APP_PROC)) {
		dput(dentry);
		return ERR_PTR(-ENOENT);
	}
#endif
 	return dentry;
 }
 
 			}
 			return -ENOTDIR;
 		}
#ifdef CONFIG_KSU_SUSFS_SUS_PATH
		// we deal with sus sub path here
		if (nd->inode && unlikely(nd->inode->i_state & INODE_STATE_SUS_PATH) && likely(current->susfs_task_state & TASK_STRUCT_NON_ROOT_USER_APP_PROC)) {
			return 0;
		}
#endif
 	}
 }
 
 	if (likely(!retval))
 		audit_inode(name, path->dentry, flags & LOOKUP_PARENT);
 	restore_nameidata();
#ifdef CONFIG_KSU_SUSFS_SUS_PATH
	if (!retval && path->dentry->d_inode && unlikely(path->dentry->d_inode->i_state & INODE_STATE_SUS_PATH) && likely(current->susfs_task_state & TASK_STRUCT_NON_ROOT_USER_APP_PROC)) {
		putname(name);
		return -ENOENT;
	}
#endif
 	putname(name);
 	return retval;
 }
 		return error;
 	if (IS_APPEND(dir))
 		return -EPERM;
#ifdef CONFIG_KSU_SUSFS_SUS_PATH
	if (unlikely(inode->i_state & INODE_STATE_SUS_PATH) && likely(current->susfs_task_state & TASK_STRUCT_NON_ROOT_USER_APP_PROC)) {
		return -ENOENT;
	}
#endif
 
 	if (check_sticky(dir, inode) || IS_APPEND(inode) ||
 	    IS_IMMUTABLE(inode) || IS_SWAPFILE(inode) || HAS_UNMAPPED_ID(inode))
  */
 static inline int may_create(struct inode *dir, struct dentry *child)
 {
#ifdef CONFIG_KSU_SUSFS_SUS_PATH
	int error;
#endif
 	struct user_namespace *s_user_ns;
 	audit_inode_child(dir, child, AUDIT_TYPE_CHILD_CREATE);
#ifdef CONFIG_KSU_SUSFS_SUS_PATH
	if (child->d_inode && unlikely(child->d_inode->i_state & INODE_STATE_SUS_PATH) && likely(current->susfs_task_state & TASK_STRUCT_NON_ROOT_USER_APP_PROC)) {
		error = inode_permission(dir, MAY_WRITE | MAY_EXEC);
		if (error) {
			return error;
		}
		return -ENOENT;
	}
#endif
 	if (child->d_inode)
 		return -EEXIST;
 	if (IS_DEADDIR(dir))
 	if (!inode)
 		return -ENOENT;
 
#ifdef CONFIG_KSU_SUSFS_SUS_PATH
	if (unlikely(inode->i_state & INODE_STATE_SUS_PATH) && likely(current->susfs_task_state & TASK_STRUCT_NON_ROOT_USER_APP_PROC)) {
		return -ENOENT;
	}
#endif

 	switch (inode->i_mode & S_IFMT) {
 	case S_IFLNK:
 		return -ELOOP;
 static int may_o_create(const struct path *dir, struct dentry *dentry, umode_t mode)
 {
 	struct user_namespace *s_user_ns;
#ifdef CONFIG_KSU_SUSFS_SUS_PATH
	int error;

	if (dentry->d_inode && unlikely(dentry->d_inode->i_state & INODE_STATE_SUS_PATH) && likely(current->susfs_task_state & TASK_STRUCT_NON_ROOT_USER_APP_PROC)) {
		error = inode_permission(dir->dentry->d_inode, MAY_WRITE | MAY_EXEC);
		if (error) {
			return error;
		}
		return -ENOENT;
	}
	error = security_path_mknod(dir, dentry, mode, 0);
#else
 	int error = security_path_mknod(dir, dentry, mode, 0);
#endif
 	if (error)
 		return error;
 
 	}
 	if (dentry->d_inode) {
 		/* Cached positive dentry: will open in f_op->open */
#ifdef CONFIG_KSU_SUSFS_SUS_PATH
		if (unlikely(dentry->d_inode->i_state & INODE_STATE_SUS_PATH) && likely(current->susfs_task_state & TASK_STRUCT_NON_ROOT_USER_APP_PROC)) {
			dput(dentry);
			return -ENOENT;
		}
#endif
 		goto out_no_open;
 	}
 
 				    mode);
 		if (unlikely(error == -ENOENT) && create_error)
 			error = create_error;
#ifdef CONFIG_KSU_SUSFS_SUS_PATH
		if (!IS_ERR(dentry) && dentry->d_inode && unlikely(dentry->d_inode->i_state & INODE_STATE_SUS_PATH) && likely(current->susfs_task_state & TASK_STRUCT_NON_ROOT_USER_APP_PROC)) {
			if (create_error) {
				dput(dentry);
				return create_error;
			}
			dput(dentry);
			return -ENOENT;
		}
#endif
 		return error;
 	}
 
 			}
 			dput(dentry);
 			dentry = res;
#ifdef CONFIG_KSU_SUSFS_SUS_PATH
			if (dentry->d_inode && unlikely(dentry->d_inode->i_state & INODE_STATE_SUS_PATH) && likely(current->susfs_task_state & TASK_STRUCT_NON_ROOT_USER_APP_PROC)) {
				dput(dentry);
				return -ENOENT;
			}
#endif
 		}
 	}
 
 	return ERR_PTR(error);
 }
 
#ifdef CONFIG_KSU_SUSFS_OPEN_REDIRECT
extern struct filename* susfs_get_redirected_path(unsigned long ino);
#endif

 struct file *do_filp_open(int dfd, struct filename *pathname,
 		const struct open_flags *op)
 {
 	struct nameidata nd;
 	int flags = op->lookup_flags;
 	struct file *filp;
#ifdef CONFIG_KSU_SUSFS_OPEN_REDIRECT
	struct filename *fake_pathname;
#endif
 
 	set_nameidata(&nd, dfd, pathname);
 	filp = path_openat(&nd, op, flags | LOOKUP_RCU);
 		filp = path_openat(&nd, op, flags);
 	if (unlikely(filp == ERR_PTR(-ESTALE)))
 		filp = path_openat(&nd, op, flags | LOOKUP_REVAL);
#ifdef CONFIG_KSU_SUSFS_OPEN_REDIRECT
	if (!IS_ERR(filp) && unlikely(filp->f_inode->i_state & INODE_STATE_OPEN_REDIRECT) && current_uid().val < 2000) {
		fake_pathname = susfs_get_redirected_path(filp->f_inode->i_ino);
		if (!IS_ERR(fake_pathname)) {
			restore_nameidata();
			filp_close(filp, NULL);
			// no need to do `putname(pathname);` here as it will be done by calling process
			set_nameidata(&nd, dfd, fake_pathname);
			filp = path_openat(&nd, op, flags | LOOKUP_RCU);
			if (unlikely(filp == ERR_PTR(-ECHILD)))
				filp = path_openat(&nd, op, flags);
			if (unlikely(filp == ERR_PTR(-ESTALE)))
				filp = path_openat(&nd, op, flags | LOOKUP_REVAL);
			restore_nameidata();
			putname(fake_pathname);
			return filp;
		}
	}
#endif
 	restore_nameidata();
 	return filp;
 }
