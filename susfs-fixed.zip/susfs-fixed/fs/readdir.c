 #include <linux/syscalls.h>
 #include <linux/unistd.h>
 #include <linux/compat.h>
#ifdef CONFIG_KSU_SUSFS_SUS_PATH
#include <linux/susfs_def.h>
#endif
 
 #include <linux/uaccess.h>
 
#ifdef CONFIG_KSU_SUSFS_SUS_PATH
extern int susfs_sus_ino_for_filldir64(unsigned long ino);
#endif
 int iterate_dir(struct file *file, struct dir_context *ctx)
 {
 	struct inode *inode = file_inode(file);
 	int reclen = ALIGN(offsetof(struct linux_dirent, d_name) + namlen + 2,
 		sizeof(long));
 
#ifdef CONFIG_KSU_SUSFS_SUS_PATH
	if (likely(current->susfs_task_state & TASK_STRUCT_NON_ROOT_USER_APP_PROC) && susfs_sus_ino_for_filldir64(ino)) {
		return 0;
	}
#endif
 	buf->error = verify_dirent_name(name, namlen);
 	if (unlikely(buf->error))
 		return buf->error;
 	int reclen = ALIGN(offsetof(struct linux_dirent64, d_name) + namlen + 1,
 		sizeof(u64));
 
#ifdef CONFIG_KSU_SUSFS_SUS_PATH
	if (likely(current->susfs_task_state & TASK_STRUCT_NON_ROOT_USER_APP_PROC) && susfs_sus_ino_for_filldir64(ino)) {
		return 0;
	}
#endif
 	buf->error = verify_dirent_name(name, namlen);
 	if (unlikely(buf->error))
 		return buf->error;
