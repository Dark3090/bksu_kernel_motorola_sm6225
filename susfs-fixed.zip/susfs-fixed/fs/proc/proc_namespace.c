 #include <linux/security.h>
 #include <linux/fs_struct.h>
 #include <linux/sched/task.h>
#ifdef CONFIG_KSU_SUSFS_SUS_MOUNT
#include <linux/susfs_def.h>
#endif
 
 #include "proc/internal.h" /* only for get_proc_task() in ->open() */
 
 	struct super_block *sb = mnt_path.dentry->d_sb;
 	int err;
 
#ifdef CONFIG_KSU_SUSFS_SUS_MOUNT
	if (unlikely(r->mnt_id >= DEFAULT_SUS_MNT_ID))
		return 0;
#endif

 	if (sb->s_op->show_devname) {
 		err = sb->s_op->show_devname(m, mnt_path.dentry);
 		if (err)
 	struct path mnt_path = { .dentry = mnt->mnt_root, .mnt = mnt };
 	int err;
 
#ifdef CONFIG_KSU_SUSFS_SUS_MOUNT
	if (unlikely(r->mnt_id >= DEFAULT_SUS_MNT_ID))
		return 0;
#endif

 	seq_printf(m, "%i %i %u:%u ", r->mnt_id, r->mnt_parent->mnt_id,
 		   MAJOR(sb->s_dev), MINOR(sb->s_dev));
 	if (sb->s_op->show_path) {
 	struct super_block *sb = mnt_path.dentry->d_sb;
 	int err;
 
#ifdef CONFIG_KSU_SUSFS_SUS_MOUNT
	if (unlikely(r->mnt_id >= DEFAULT_SUS_MNT_ID))
		return 0;
#endif

 	/* device */
 	if (sb->s_op->show_devname) {
 		seq_puts(m, "device ");
