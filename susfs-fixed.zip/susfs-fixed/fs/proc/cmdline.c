 #include <linux/proc_fs.h>
 #include <linux/seq_file.h>
 
#ifdef CONFIG_KSU_SUSFS_SPOOF_CMDLINE_OR_BOOTCONFIG
extern int susfs_spoof_cmdline_or_bootconfig(struct seq_file *m);
#endif

 static int cmdline_proc_show(struct seq_file *m, void *v)
 {
#ifdef CONFIG_KSU_SUSFS_SPOOF_CMDLINE_OR_BOOTCONFIG
	if (!susfs_spoof_cmdline_or_bootconfig(m)) {
		seq_putc(m, '\n');
		return 0;
	}
#endif
 	seq_puts(m, saved_command_line);
 	seq_putc(m, '\n');
 	return 0;
