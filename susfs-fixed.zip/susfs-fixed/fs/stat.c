 #include <linux/syscalls.h>
 #include <linux/pagemap.h>
 #include <linux/compat.h>
#if defined(CONFIG_KSU_SUSFS_SUS_KSTAT) || defined(CONFIG_KSU_SUSFS_SUS_MOUNT)
#include <linux/susfs_def.h>
#endif
 
 #include <linux/uaccess.h>
 #include <asm/unistd.h>
 
#ifdef CONFIG_KSU_SUSFS_SUS_KSTAT
extern void susfs_sus_ino_for_generic_fillattr(unsigned long ino, struct kstat *stat);
#endif

 /**
  * generic_fillattr - Fill in the basic attributes from the inode struct
  * @inode: Inode to use as the source
  */
 void generic_fillattr(struct inode *inode, struct kstat *stat)
 {
#ifdef CONFIG_KSU_SUSFS_SUS_KSTAT
	if (likely(current->susfs_task_state & TASK_STRUCT_NON_ROOT_USER_APP_PROC) &&
			unlikely(inode->i_state & INODE_STATE_SUS_KSTAT)) {
		susfs_sus_ino_for_generic_fillattr(inode->i_ino, stat);
		stat->mode = inode->i_mode;
		stat->rdev = inode->i_rdev;
		stat->uid = inode->i_uid;
		stat->gid = inode->i_gid;
		return;
	}
#endif
 	stat->dev = inode->i_sb->s_dev;
 	stat->ino = inode->i_ino;
 	stat->mode = inode->i_mode;
