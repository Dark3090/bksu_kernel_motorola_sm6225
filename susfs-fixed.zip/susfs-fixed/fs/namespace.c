 #include <linux/bootmem.h>
 #include <linux/task_work.h>
 #include <linux/sched/task.h>
#if defined(CONFIG_KSU_SUSFS_SUS_MOUNT) || defined(CONFIG_KSU_SUSFS_TRY_UMOUNT)
#include <linux/susfs_def.h>
#endif
 
 #include "pnode.h"
 #include "internal.h"
 
#ifdef CONFIG_KSU_SUSFS_SUS_MOUNT
extern bool susfs_is_current_ksu_domain(void);
extern bool susfs_is_current_zygote_domain(void);

static DEFINE_IDA(susfs_mnt_id_ida);
static DEFINE_IDA(susfs_mnt_group_ida);

#define CL_ZYGOTE_COPY_MNT_NS BIT(24) /* used by copy_mnt_ns() */
#define CL_COPY_MNT_NS BIT(25) /* used by copy_mnt_ns() */
#endif

#ifdef CONFIG_KSU_SUSFS_AUTO_ADD_SUS_KSU_DEFAULT_MOUNT
extern void susfs_auto_add_sus_ksu_default_mount(const char __user *to_pathname);
bool susfs_is_auto_add_sus_ksu_default_mount_enabled = true;
#endif
#ifdef CONFIG_KSU_SUSFS_AUTO_ADD_SUS_BIND_MOUNT
extern int susfs_auto_add_sus_bind_mount(const char *pathname, struct path *path_target);
bool susfs_is_auto_add_sus_bind_mount_enabled = true;
#endif
#ifdef CONFIG_KSU_SUSFS_AUTO_ADD_TRY_UMOUNT_FOR_BIND_MOUNT
extern void susfs_auto_add_try_umount_for_bind_mount(struct path *path);
bool susfs_is_auto_add_try_umount_for_bind_mount_enabled = true;
#endif

 /* Maximum number of mounts in a mount namespace */
 unsigned int sysctl_mount_max __read_mostly = 100000;
 
 	return &mountpoint_hashtable[tmp & mp_hash_mask];
 }
 
#ifdef CONFIG_KSU_SUSFS_SUS_MOUNT
// Our own mnt_alloc_id() that assigns mnt_id starting from DEFAULT_SUS_MNT_ID
static int susfs_mnt_alloc_id(struct mount *mnt)
{
	int res = ida_alloc_min(&susfs_mnt_id_ida, DEFAULT_SUS_MNT_ID, GFP_KERNEL);

	if (res < 0)
		return res;
	mnt->mnt_id = res;
	return 0;
}
#endif
 static int mnt_alloc_id(struct mount *mnt)
 {
 	int res = ida_alloc(&mnt_id_ida, GFP_KERNEL);
 
 static void mnt_free_id(struct mount *mnt)
 {
#ifdef CONFIG_KSU_SUSFS_SUS_MOUNT
	// We should first check the 'mnt->mnt.susfs_mnt_id_backup', see if it is DEFAULT_SUS_MNT_ID_FOR_KSU_PROC_UNSHARE
	// if so, these mnt_id were not assigned by mnt_alloc_id() so we don't need to free it.
	if (unlikely(mnt->mnt.susfs_mnt_id_backup == DEFAULT_SUS_MNT_ID_FOR_KSU_PROC_UNSHARE)) {
		return;
	}
	// Now we can check if its mnt_id is sus
	if (unlikely(mnt->mnt_id >= DEFAULT_SUS_MNT_ID)) {
		ida_free(&susfs_mnt_id_ida, mnt->mnt_id);
		return;
	}
	// Lastly if 'mnt->mnt.susfs_mnt_id_backup' is not 0, then it contains a backup origin mnt_id
	// so we free it in the original way
	if (likely(mnt->mnt.susfs_mnt_id_backup)) {
		// If mnt->mnt.susfs_mnt_id_backup is not zero, it means mnt->mnt_id is spoofed,
		// so here we return the original mnt_id for being freed.
		ida_free(&mnt_id_ida, mnt->mnt.susfs_mnt_id_backup);
		return;
	}
#endif
 	ida_free(&mnt_id_ida, mnt->mnt_id);
 }
 
  */
 static int mnt_alloc_group_id(struct mount *mnt)
 {
#ifdef CONFIG_KSU_SUSFS_SUS_MOUNT
	int res;

	// Check if mnt has sus mnt_id
	if (mnt->mnt_id >= DEFAULT_SUS_MNT_ID) {
		// If so, assign a sus mnt_group id DEFAULT_SUS_MNT_GROUP_ID from susfs_mnt_group_ida
		res = ida_alloc_min(&susfs_mnt_group_ida, DEFAULT_SUS_MNT_GROUP_ID, GFP_KERNEL);
		goto bypass_orig_flow;
	}
	res = ida_alloc_min(&mnt_group_ida, 1, GFP_KERNEL);
bypass_orig_flow:
#else
 	int res = ida_alloc_min(&mnt_group_ida, 1, GFP_KERNEL);
#endif
 
 	if (res < 0)
 		return res;
  */
 void mnt_release_group_id(struct mount *mnt)
 {
#ifdef CONFIG_KSU_SUSFS_SUS_MOUNT
	// If mnt->mnt_group_id >= DEFAULT_SUS_MNT_GROUP_ID, it means 'mnt' is also sus mount,
	// then we free the mnt->mnt_group_id from susfs_mnt_group_ida
	if (mnt->mnt_group_id >= DEFAULT_SUS_MNT_GROUP_ID) {
		ida_free(&susfs_mnt_group_ida, mnt->mnt_group_id);
		mnt->mnt_group_id = 0;
		return;
	}
#endif
 	ida_free(&mnt_group_ida, mnt->mnt_group_id);
 	mnt->mnt_group_id = 0;
 }
 	mntput(&m->mnt);
 }
 
#ifdef CONFIG_KSU_SUSFS_SUS_MOUNT
static struct mount *alloc_vfsmnt(const char *name, bool should_spoof, int custom_mnt_id)
#else
 static struct mount *alloc_vfsmnt(const char *name)
#endif
 {
 	struct mount *mnt = kmem_cache_zalloc(mnt_cache, GFP_KERNEL);
 	if (mnt) {
 		int err;
 
#ifdef CONFIG_KSU_SUSFS_SUS_MOUNT
		if (should_spoof) {
			if (!custom_mnt_id) {
				err = susfs_mnt_alloc_id(mnt);
			} else {
				mnt->mnt_id = custom_mnt_id;
				err = 0;
			}
			goto bypass_orig_flow;
		}
#endif
 		err = mnt_alloc_id(mnt);
#ifdef CONFIG_KSU_SUSFS_SUS_MOUNT
bypass_orig_flow:
#endif
 		if (err)
 			goto out_free_cache;
 
 	if (!type)
 		return ERR_PTR(-ENODEV);
 
#ifdef CONFIG_KSU_SUSFS_SUS_MOUNT
	// For newly created mounts, the only caller process we care is KSU
	if (unlikely(susfs_is_current_ksu_domain())) {
		mnt = alloc_vfsmnt(name, true, 0);
		goto bypass_orig_flow;
	}
	mnt = alloc_vfsmnt(name, false, 0);
bypass_orig_flow:
#else
 	mnt = alloc_vfsmnt(name);
#endif
 	if (!mnt)
 		return ERR_PTR(-ENOMEM);
 
 	mnt->mnt.mnt_sb = root->d_sb;
 	mnt->mnt_mountpoint = mnt->mnt.mnt_root;
 	mnt->mnt_parent = mnt;

#ifdef CONFIG_KSU_SUSFS_SUS_MOUNT
	// If caller process is zygote, then it is a normal mount, so we just reorder the mnt_id
	if (susfs_is_current_zygote_domain()) {
		mnt->mnt.susfs_mnt_id_backup = mnt->mnt_id;
		mnt->mnt_id = current->susfs_last_fake_mnt_id++;
	}
#endif

 	lock_mount_hash();
 	list_add_tail(&mnt->mnt_instance, &root->d_sb->s_mounts);
 	unlock_mount_hash();
 	mnt->mnt.mnt_root = dget(root);
 	mnt->mnt_mountpoint = mnt->mnt.mnt_root;
 	mnt->mnt_parent = mnt;

#ifdef CONFIG_KSU_SUSFS_SUS_MOUNT
	// If caller process is zygote and not doing unshare, so we just reorder the mnt_id
	if (likely(is_current_zygote_domain) && !(flag & CL_ZYGOTE_COPY_MNT_NS)) {
		mnt->mnt.susfs_mnt_id_backup = mnt->mnt_id;
		mnt->mnt_id = current->susfs_last_fake_mnt_id++;
	}
#endif

 	lock_mount_hash();
 	list_add_tail(&mnt->mnt_instance, &sb->s_mounts);
 	unlock_mount_hash();
 		umount_tree(mnt, UMOUNT_SYNC);
 		unlock_mount_hash();
 	}
#if defined(CONFIG_KSU_SUSFS_AUTO_ADD_SUS_BIND_MOUNT) || defined(CONFIG_KSU_SUSFS_AUTO_ADD_TRY_UMOUNT_FOR_BIND_MOUNT)
	// Check if bind mounted path should be hidden and umounted automatically.
	// And we target only process with ksu domain.
	if (susfs_is_current_ksu_domain()) {
#if defined(CONFIG_KSU_SUSFS_AUTO_ADD_SUS_BIND_MOUNT)
		if (susfs_is_auto_add_sus_bind_mount_enabled &&
				susfs_auto_add_sus_bind_mount(old_name, &old_path)) {
			goto orig_flow;
		}
#endif
#if defined(CONFIG_KSU_SUSFS_AUTO_ADD_TRY_UMOUNT_FOR_BIND_MOUNT)
		if (susfs_is_auto_add_try_umount_for_bind_mount_enabled) {
			susfs_auto_add_try_umount_for_bind_mount(path);
		}
#endif
	}
#if defined(CONFIG_KSU_SUSFS_AUTO_ADD_SUS_BIND_MOUNT)
orig_flow:
#endif
#endif // #if defined(CONFIG_KSU_SUSFS_AUTO_ADD_SUS_BIND_MOUNT) || defined(CONFIG_KSU_SUSFS_AUTO_ADD_TRY_UMOUNT_FOR_BIND_MOUNT)

 out2:
 	unlock_mount(mp);
 out:
 	else
 		retval = do_new_mount(&path, type_page, sb_flags, mnt_flags,
 				      dev_name, data_page);
#ifdef CONFIG_KSU_SUSFS_AUTO_ADD_SUS_KSU_DEFAULT_MOUNT
	// For both Legacy and Magic Mount KernelSU
	if (!retval && susfs_is_auto_add_sus_ksu_default_mount_enabled &&
			(!(flags & (MS_REMOUNT | MS_BIND | MS_SHARED | MS_PRIVATE | MS_SLAVE | MS_UNBINDABLE)))) {
		if (susfs_is_current_ksu_domain()) {
			susfs_auto_add_sus_ksu_default_mount(dir_name);
		}
	}
#endif
 dput_out:
 	path_put(&path);
 	return retval;
 	struct mount *old;
 	struct mount *new;
 	int copy_flags;
#ifdef CONFIG_KSU_SUSFS_SUS_MOUNT
	bool is_zygote_pid = susfs_is_current_zygote_domain();
	int last_entry_mnt_id = 0;
#endif
 
 	BUG_ON(!ns);
 
 	copy_flags = CL_COPY_UNBINDABLE | CL_EXPIRE;
 	if (user_ns != ns->user_ns)
 		copy_flags |= CL_SHARED_TO_SLAVE | CL_UNPRIVILEGED;
#ifdef CONFIG_KSU_SUSFS_SUS_MOUNT
	// Always let clone_mnt() in copy_tree() know it is from copy_mnt_ns()
	copy_flags |= CL_COPY_MNT_NS;
	if (is_zygote_pid) {
		// Let clone_mnt() in copy_tree() know copy_mnt_ns() is run by zygote process
		copy_flags |= CL_ZYGOTE_COPY_MNT_NS;
	}
#endif

 	new = copy_tree(old, old->mnt.mnt_root, copy_flags);
 	if (IS_ERR(new)) {
 		namespace_unlock();
 		while (p->mnt.mnt_root != q->mnt.mnt_root)
 			p = next_mnt(p, old);
 	}
#ifdef CONFIG_KSU_SUSFS_SUS_MOUNT
	// current->susfs_last_fake_mnt_id -> to record last valid fake mnt_id to zygote pid
	// q->mnt.susfs_mnt_id_backup -> original mnt_id
	// q->mnt_id -> will be modified to the fake mnt_id

	// Here We are only interested in processes of which original mnt namespace belongs to zygote 
	// Also we just make use of existing 'q' mount pointer, no need to delcare extra mount pointer
	if (is_zygote_pid) {
		last_entry_mnt_id = list_first_entry(&new_ns->list, struct mount, mnt_list)->mnt_id;
		list_for_each_entry(q, &new_ns->list, mnt_list) {
			if (unlikely(q->mnt_id >= DEFAULT_SUS_MNT_ID)) {
				continue;
			}
			q->mnt.susfs_mnt_id_backup = q->mnt_id;
			q->mnt_id = last_entry_mnt_id++;
		}
	}
	// Assign the 'last_entry_mnt_id' to 'current->susfs_last_fake_mnt_id' for later use.
	// should be fine here assuming zygote is forking/unsharing app in one single thread.
	// Or should we put a lock here?
	current->susfs_last_fake_mnt_id = last_entry_mnt_id;
#endif

 	namespace_unlock();
 
 	if (rootmnt)
 	.install	= mntns_install,
 	.owner		= mntns_owner,
 };

#ifdef CONFIG_KSU_SUSFS_TRY_UMOUNT
extern void susfs_try_umount_all(uid_t uid);
void susfs_run_try_umount_for_current_mnt_ns(void) {
	struct mount *mnt;
	struct mnt_namespace *mnt_ns;

	mnt_ns = current->nsproxy->mnt_ns;
	// Lock the namespace
	namespace_lock();
	list_for_each_entry(mnt, &mnt_ns->list, mnt_list) {
		// Change the sus mount to be private
		if (mnt->mnt_id >= DEFAULT_SUS_MNT_ID) {
			change_mnt_propagation(mnt, MS_PRIVATE);
		}
	}
	// Unlock the namespace
	namespace_unlock();
	susfs_try_umount_all(current_uid().val);
}
#endif
#ifdef CONFIG_KSU_SUSFS
bool susfs_is_mnt_devname_ksu(struct path *path) {
	struct mount *mnt;

	if (path && path->mnt) {
		mnt = real_mount(path->mnt);
		if (mnt && mnt->mnt_devname && !strcmp(mnt->mnt_devname, "KSU")) {
			return true;
		}
	}
	return false;
}
#endif
