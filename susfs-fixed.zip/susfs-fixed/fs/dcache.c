 #include <linux/bit_spinlock.h>
 #include <linux/rculist_bl.h>
 #include <linux/list_lru.h>
#ifdef CONFIG_KSU_SUSFS_SUS_PATH
#include <linux/susfs_def.h>
#endif
 #include "internal.h"
 #include "mount.h"
 
 				continue;
 			if (dentry_cmp(dentry, str, hashlen_len(hashlen)) != 0)
 				continue;
#ifdef CONFIG_KSU_SUSFS_SUS_PATH
			if (dentry->d_inode && unlikely(dentry->d_inode->i_state & INODE_STATE_SUS_PATH) && likely(current->susfs_task_state & TASK_STRUCT_NON_ROOT_USER_APP_PROC)) {
				continue;
			}
#endif
 		}
 		*seqp = seq;
 		return dentry;
 		if (dentry->d_name.hash != hash)
 			continue;
 
#ifdef CONFIG_KSU_SUSFS_SUS_PATH
		if (dentry->d_inode && unlikely(dentry->d_inode->i_state & INODE_STATE_SUS_PATH) && likely(current->susfs_task_state & TASK_STRUCT_NON_ROOT_USER_APP_PROC)) {
			continue;
		}
#endif

 		spin_lock(&dentry->d_lock);
 		if (dentry->d_parent != parent)
 			goto next;
