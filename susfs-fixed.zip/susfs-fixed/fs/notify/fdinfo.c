 #include <linux/seq_file.h>
 #include <linux/proc_fs.h>
 #include <linux/exportfs.h>
#ifdef CONFIG_KSU_SUSFS_SUS_MOUNT
#include <linux/susfs_def.h>
#endif
 
 #include "inotify/inotify.h"
 #include "fsnotify.h"
 
 #if defined(CONFIG_INOTIFY_USER) || defined(CONFIG_FANOTIFY)
 
#ifdef CONFIG_KSU_SUSFS_SUS_MOUNT
static void show_fdinfo(struct seq_file *m, struct file *f,
			void (*show)(struct seq_file *m,
				     struct fsnotify_mark *mark,
					 struct file *file))
#else
 static void show_fdinfo(struct seq_file *m, struct file *f,
 			void (*show)(struct seq_file *m,
 				     struct fsnotify_mark *mark))
#endif
 {
 	struct fsnotify_group *group = f->private_data;
 	struct fsnotify_mark *mark;
 
 	mutex_lock(&group->mark_mutex);
 	list_for_each_entry(mark, &group->marks_list, g_list) {
#ifdef CONFIG_KSU_SUSFS_SUS_MOUNT
		show(m, mark, f);
#else
 		show(m, mark);
#endif
 		if (seq_has_overflowed(m))
 			break;
 	}
 
 #ifdef CONFIG_INOTIFY_USER
 
#ifdef CONFIG_KSU_SUSFS_SUS_MOUNT
static void inotify_fdinfo(struct seq_file *m, struct fsnotify_mark *mark, struct file *file)
#else
 static void inotify_fdinfo(struct seq_file *m, struct fsnotify_mark *mark)
#endif
 {
 	struct inotify_inode_mark *inode_mark;
 	struct inode *inode;
 	inode_mark = container_of(mark, struct inotify_inode_mark, fsn_mark);
 	inode = igrab(fsnotify_conn_inode(mark->connector));
 	if (inode) {
#ifdef CONFIG_KSU_SUSFS_SUS_MOUNT
		if (likely(current->susfs_task_state & TASK_STRUCT_NON_ROOT_USER_APP_PROC) &&
				unlikely(inode->i_state & INODE_STATE_SUS_KSTAT)) {
			struct path path;
			char *pathname = kmalloc(PAGE_SIZE, GFP_KERNEL);
			char *dpath;
			if (!pathname) {
				goto out_seq_printf;
			}
			dpath = d_path(&file->f_path, pathname, PAGE_SIZE);
			if (!dpath) {
				goto out_free_pathname;
			}
			if (kern_path(dpath, 0, &path)) {
				goto out_free_pathname;
			}
			seq_printf(m, "inotify wd:%x ino:%lx sdev:%x mask:%x ignored_mask:0 ",
			   inode_mark->wd, path.dentry->d_inode->i_ino, path.dentry->d_inode->i_sb->s_dev,
			   inotify_mark_user_mask(mark));
			show_mark_fhandle(m, path.dentry->d_inode);
			seq_putc(m, '\n');
			iput(inode);
			path_put(&path);
			kfree(pathname);
			return;
out_free_pathname:
			kfree(pathname);
		}
out_seq_printf:
#endif
 		seq_printf(m, "inotify wd:%x ino:%lx sdev:%x mask:%x ignored_mask:0 ",
 			   inode_mark->wd, inode->i_ino, inode->i_sb->s_dev,
 			   inotify_mark_user_mask(mark));
